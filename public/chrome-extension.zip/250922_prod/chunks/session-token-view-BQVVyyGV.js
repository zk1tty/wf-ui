import { u as useWorkflow, r as reactExports, e as ensureAuth, j as jsxRuntimeExports, A as ArrowLeft, B as Button, C as Check, b as Copy, X } from "./sidepanel-B5N0sQcr.js";
const SessionTokenView = () => {
  const { goHomeView } = useWorkflow();
  const [token, setToken] = reactExports.useState(null);
  const [copied, setCopied] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  reactExports.useEffect(() => {
    (async () => {
      try {
        const t = await ensureAuth();
        setToken(t);
      } catch (e) {
        setError((e == null ? void 0 : e.message) ?? "Failed to get token");
      }
    })();
  }, []);
  const copy = async () => {
    if (!token) return;
    try {
      await navigator.clipboard.writeText(token);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setError("Failed to copy to clipboard");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold", children: "Login app" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "text-sm text-gray-600 hover:text-black flex items-center gap-1", onClick: goHomeView, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" }),
        " Back"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-blue-50 rounded-lg p-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm text-blue-800", children: [
      "Copy token and go to ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://app.rebrowse.me", target: "_blank", rel: "noopener noreferrer", className: "underline font-medium", children: "app.rebrowse.me" })
    ] }) }),
    error && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-red-600", children: error }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded border p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-gray-500 mb-1", children: "Session Token:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-mono text-xs text-gray-800 break-all bg-gray-50 p-2 rounded min-h-10", children: token ?? "Loading..." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", onClick: copy, className: "flex-1", children: copied ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-4 w-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "h-4 w-4" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", size: "sm", onClick: goHomeView, children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }) })
      ] })
    ] })
  ] });
};
export {
  SessionTokenView as default
};
//# sourceMappingURL=session-token-view-BQVVyyGV.js.map
