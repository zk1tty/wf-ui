var getGlobal = function() {
  if (typeof self !== "undefined") {
    return self;
  }
  if (typeof window !== "undefined") {
    return window;
  }
  if (typeof global !== "undefined") {
    return global;
  }
  throw new Error("unable to locate global object");
};
var globalObject = getGlobal();
globalObject.fetch;
const browser = globalObject.fetch.bind(globalObject);
globalObject.Headers;
globalObject.Request;
globalObject.Response;
export {
  browser as default
};
//# sourceMappingURL=browser-C2PL2Vid.js.map
