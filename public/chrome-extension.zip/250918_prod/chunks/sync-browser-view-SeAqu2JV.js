import { c as createLucideIcon, u as useWorkflow, R as React, j as jsxRuntimeExports, B as Button, e as ensureAuth } from "./sidepanel-BEoZIaBF.js";
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$5 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
];
const CircleCheck = createLucideIcon("circle-check", __iconNode$5);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$4 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }]
];
const CircleDot = createLucideIcon("circle-dot", __iconNode$4);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$3 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "m9 9 6 6", key: "z0biqf" }]
];
const CircleX = createLucideIcon("circle-x", __iconNode$3);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$2 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["polyline", { points: "12 6 12 12 16 14", key: "68esgv" }]
];
const Clock = createLucideIcon("clock", __iconNode$2);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$1 = [
  ["path", { d: "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z", key: "p7xjir" }]
];
const Cloud = createLucideIcon("cloud", __iconNode$1);
/**
 * @license lucide-react v0.507.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode = [
  ["path", { d: "M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5", key: "laymnq" }],
  ["path", { d: "M8.5 8.5v.01", key: "ue8clq" }],
  ["path", { d: "M16 15.5v.01", key: "14dtrp" }],
  ["path", { d: "M12 12v.01", key: "u5ubse" }],
  ["path", { d: "M11 17v.01", key: "1hyl5a" }],
  ["path", { d: "M7 14v.01", key: "uct60s" }]
];
const Cookie = createLucideIcon("cookie", __iconNode);
const COOKIE_SITES = {
  x: {
    id: "x",
    label: "X",
    hostPermissions: ["https://x.com/*"],
    cookieDomains: ["x.com", ".x.com"],
    enabledByDefault: true,
    requiredCookies: ["auth_token"],
    loginUrl: "https://x.com/login"
  },
  linkedin: {
    id: "linkedin",
    label: "LinkedIn",
    hostPermissions: ["https://*.linkedin.com/*"],
    cookieDomains: [
      "linkedin.com",
      ".linkedin.com",
      "www.linkedin.com",
      ".www.linkedin.com",
      "login.linkedin.com",
      ".login.linkedin.com"
    ],
    enabledByDefault: true,
    requiredCookies: ["li_at"],
    loginUrl: "https://www.linkedin.com/login"
  },
  tiktok: {
    id: "tiktok",
    label: "TikTok",
    hostPermissions: ["https://*.tiktok.com/*"],
    cookieDomains: ["tiktok.com", ".tiktok.com", "www.tiktok.com", ".www.tiktok.com"],
    enabledByDefault: true,
    loginUrl: "https://www.tiktok.com/login",
    requiredCookies: ["sessionid"]
  },
  instagram: {
    id: "instagram",
    label: "Instagram",
    hostPermissions: ["https://*.instagram.com/*"],
    cookieDomains: [
      "instagram.com",
      ".instagram.com",
      "www.instagram.com",
      ".www.instagram.com",
      "m.instagram.com",
      ".m.instagram.com"
    ],
    enabledByDefault: true,
    requiredCookies: ["sessionid"],
    loginUrl: "https://www.instagram.com/accounts/login"
  },
  facebook: {
    id: "facebook",
    label: "Facebook",
    hostPermissions: ["https://*.facebook.com/*"],
    cookieDomains: ["facebook.com", ".facebook.com", "www.facebook.com", ".www.facebook.com"],
    enabledByDefault: true,
    requiredCookies: ["c_user", "xs"],
    loginUrl: "https://www.facebook.com/login"
  }
};
const SITE_ICON_LABELS = {
  x: "X",
  linkedin: "LinkedIn",
  tiktok: "TikTok",
  instagram: "Instagram",
  facebook: "Facebook",
  other: "Other"
};
const toUniqueSorted = (arr) => Array.from(new Set(arr)).sort();
const getAllGrantedOrigins = async () => {
  const all = await chrome.permissions.getAll();
  return toUniqueSorted(all.origins ?? []);
};
const checkOrigins = async (origins) => {
  const required = toUniqueSorted(origins);
  const grantedOrigins = await getAllGrantedOrigins();
  const grantedSet = new Set(grantedOrigins);
  const hasAllUrls = grantedSet.has("<all_urls>") || grantedSet.has("https://*/*") && grantedSet.has("http://*/*");
  const isGranted = (origin) => hasAllUrls || grantedSet.has(origin);
  const granted = required.filter((o) => isGranted(o));
  const missing = required.filter((o) => !isGranted(o));
  return { required, granted, missing };
};
const requestOrigins = async (origins) => {
  const unique = toUniqueSorted(origins);
  if (unique.length === 0) {
    return { requested: [], granted: [], denied: [], success: true };
  }
  const allGranted = await chrome.permissions.request({ origins: unique });
  const check = await checkOrigins(unique);
  const granted = check.granted;
  const denied = check.missing;
  return {
    requested: unique,
    granted,
    denied,
    success: allGranted && denied.length === 0
  };
};
const ensureOrigins = async (origins, options = { interactive: true }) => {
  const check = await checkOrigins(origins);
  if (check.missing.length === 0) return check;
  if (!options.interactive) {
    return check;
  }
  return requestOrigins(check.missing);
};
const getSiteHostPermissions = (siteId) => {
  const site = COOKIE_SITES[siteId];
  return toUniqueSorted(site.hostPermissions);
};
const ensureSitePermissions = async (siteId, options = { interactive: true }) => {
  const origins = getSiteHostPermissions(siteId);
  return ensureOrigins(origins, options);
};
const toAscii = (h) => {
  try {
    const u = new URL(`http://${h}`);
    return u.hostname;
  } catch {
    return h;
  }
};
const strip = (s) => s.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*/, "").replace(/:\d+$/, "");
const heuristicApex = (host) => {
  const parts = host.split(".").filter(Boolean);
  if (parts.length <= 2) return host;
  const twoPartTlds = /* @__PURE__ */ new Set(["co.uk", "com.au", "co.jp"]);
  const last2 = parts.slice(-2).join(".");
  parts.slice(-3).join(".");
  if (twoPartTlds.has(last2)) return parts.slice(-3).join(".");
  return last2;
};
function normalizeDomain(input) {
  const stripped = strip(input);
  const hostname = toAscii(stripped);
  if (!hostname || hostname.includes("*") || !hostname.includes(".")) {
    throw new Error("Invalid domain");
  }
  const apex = heuristicApex(hostname);
  return {
    input,
    hostname,
    apex,
    permissionPatterns: [`https://${apex}/*`, `https://*.${apex}/*`],
    cookieDomains: [apex, `.${apex}`]
  };
}
const defaultSelected = Object.keys(COOKIE_SITES).filter((id) => COOKIE_SITES[id].enabledByDefault);
const SyncBrowserView = () => {
  const { goHomeView } = useWorkflow();
  const [selectedSites] = React.useState(defaultSelected);
  const [othersInput, setOthersInput] = React.useState("");
  const [requestId, setRequestId] = React.useState(null);
  const [statuses, setStatuses] = React.useState({});
  const [toast, setToast] = React.useState(null);
  const [uploading, setUploading] = React.useState(false);
  const formatTime = (ms) => ms ? new Date(ms).toLocaleTimeString() : "-";
  const StatusIcon = ({ status }) => {
    switch (status) {
      case "success":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-green-600" });
      case "failed":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "w-4 h-4 text-red-600" });
      case "processing":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-4 h-4 text-blue-600" });
      default:
        return /* @__PURE__ */ jsxRuntimeExports.jsx(CircleDot, { className: "w-4 h-4 text-gray-400" });
    }
  };
  const VerifyIcon = ({ verified }) => {
    if (verified === void 0) return null;
    return verified ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-green-600" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-red-600" });
  };
  React.useEffect(() => {
    const handler = (message) => {
      var _a, _b;
      if (!requestId) return;
      if ((message == null ? void 0 : message.type) === "COOKIE_SYNC_PROGRESS" && ((_a = message.payload) == null ? void 0 : _a.requestId) === requestId) {
        const site = message.payload.site;
        setStatuses((prev) => ({ ...prev, [site.siteId]: { status: site.status, lastUpdated: site.lastUpdated, message: site.message } }));
      }
      if ((message == null ? void 0 : message.type) === "COOKIE_SYNC_DONE" && ((_b = message.payload) == null ? void 0 : _b.requestId) === requestId) {
        const results = message.payload.results;
        setStatuses((prev) => {
          const merged = { ...prev };
          results.forEach((r) => {
            merged[r.siteId] = { status: r.status, lastUpdated: r.lastUpdated, message: r.message };
          });
          return merged;
        });
      }
    };
    chrome.runtime.onMessage.addListener(handler);
    return () => chrome.runtime.onMessage.removeListener(handler);
  }, [requestId]);
  React.useEffect(() => {
    const key = "cookieSyncStatusMap";
    chrome.storage.local.get([key]).then((res) => {
      const map = (res == null ? void 0 : res[key]) ?? {};
      setStatuses(map);
    }).catch(() => {
    });
    const onChanged = (changes, areaName) => {
      if (areaName !== "local") return;
      const change = changes["cookieSyncStatusMap"];
      if (!change) return;
      const newMap = change.newValue;
      if (newMap) setStatuses(newMap);
    };
    chrome.storage.onChanged.addListener(onChanged);
    return () => chrome.storage.onChanged.removeListener(onChanged);
  }, []);
  const parseOthers = React.useCallback(() => {
    return othersInput.split(/[\,\s]+/).map((s) => s.trim()).filter(Boolean);
  }, [othersInput]);
  const startSync = async () => {
    const rid = (crypto == null ? void 0 : crypto.randomUUID) && crypto.randomUUID() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    setRequestId(rid);
    const initial = {};
    selectedSites.forEach((id) => {
      initial[id] = { status: "ready", lastUpdated: Date.now() };
    });
    parseOthers().forEach((d) => {
      initial[`other:${d}`] = { status: "ready", lastUpdated: Date.now() };
    });
    setStatuses((prev) => ({ ...prev, ...initial }));
    const grantedSites = [];
    for (const id of selectedSites) {
      try {
        const perm = await ensureSitePermissions(id, { interactive: true });
        const denied = "denied" in perm ? perm.denied : perm.missing;
        if (denied && denied.length) {
          setStatuses((prev) => ({ ...prev, [id]: { status: "failed", lastUpdated: Date.now(), message: "Permission denied" } }));
        } else {
          grantedSites.push(id);
        }
      } catch (e) {
        setStatuses((prev) => ({ ...prev, [id]: { status: "failed", lastUpdated: Date.now(), message: "Permission error" } }));
      }
    }
    const others = parseOthers();
    const grantedOthers = [];
    for (const d of others) {
      const key = `other:${d}`;
      try {
        const norm = normalizeDomain(d);
        const origins = norm.permissionPatterns;
        const perm = await ensureOrigins(origins, { interactive: true });
        const denied = "denied" in perm ? perm.denied : perm.missing;
        if (denied && denied.length) {
          setStatuses((prev) => ({ ...prev, [key]: { status: "failed", lastUpdated: Date.now(), message: "Permission denied" } }));
        } else {
          grantedOthers.push(norm.apex);
        }
      } catch (e) {
        setStatuses((prev) => ({ ...prev, [key]: { status: "failed", lastUpdated: Date.now(), message: "Permission error" } }));
      }
    }
    if (grantedSites.length === 0 && grantedOthers.length === 0) {
      console.warn("[SyncBrowserView] No permissions granted; aborting sync");
      return;
    }
    chrome.runtime.sendMessage({
      type: "START_COOKIE_SYNC",
      payload: { requestId: rid, sites: grantedSites, others: grantedOthers }
    }, (resp) => {
      if (chrome.runtime.lastError) {
        console.error("[SyncBrowserView] START_COOKIE_SYNC failed:", chrome.runtime.lastError.message);
      }
    });
  };
  const uploadToCloud = async () => {
    try {
      setUploading(true);
      const rid = (crypto == null ? void 0 : crypto.randomUUID) && crypto.randomUUID() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const others = parseOthers();
      const resp = await new Promise((resolve) => {
        chrome.runtime.sendMessage({
          type: "BUILD_COOKIES_JSON",
          payload: { sites: selectedSites, others }
        }, (r) => resolve(r));
      });
      if (!(resp == null ? void 0 : resp.ok)) {
        console.error("[SyncBrowserView] BUILD_COOKIES_JSON failed:", resp == null ? void 0 : resp.error);
        return;
      }
      const payloadJson = resp.json;
      const accessToken = await ensureAuth();
      let ott = "";
      try {
        const res = await fetch(`${"https://wf-be.up.railway.app"}/auth/ott`, {
          method: "POST",
          headers: { "Authorization": `Bearer ${accessToken}` }
        });
        if (!res.ok) throw new Error(`OTT mint failed: ${res.status}`);
        const data = await res.json();
        ott = data == null ? void 0 : data.ott;
        if (!ott) throw new Error("OTT not returned");
      } catch (e) {
        console.error("[SyncBrowserView] mint OTT failed:", e);
        return;
      }
      chrome.runtime.sendMessage({
        type: "UPLOAD_COOKIES_ENCRYPTED",
        payload: { payloadJson, ott, sites: selectedSites }
      }, (uploadResp) => {
        var _a;
        if (chrome.runtime.lastError) {
          console.error("[SyncBrowserView] UPLOAD_COOKIES_ENCRYPTED lastError:", chrome.runtime.lastError.message);
          setToast({ type: "error", message: "Upload failed" });
          setTimeout(() => setToast(null), 2500);
          setUploading(false);
          return;
        }
        console.log("[SyncBrowserView] UPLOAD_COOKIES_ENCRYPTED:", uploadResp);
        if (uploadResp == null ? void 0 : uploadResp.ok) {
          setToast({ type: "success", message: "Succesfully uploaded to cloud" });
          const verified = (_a = uploadResp == null ? void 0 : uploadResp.result) == null ? void 0 : _a.verified;
          if (verified) {
            setStatuses((prev) => {
              const copy = { ...prev };
              const now = Date.now();
              Object.entries(verified).forEach(([siteId, ok]) => {
                copy[siteId] = {
                  status: ok ? "success" : "failed",
                  lastUpdated: now,
                  message: ok ? void 0 : "Server verification failed",
                  verified: ok
                };
              });
              return copy;
            });
          }
        } else {
          setToast({ type: "error", message: "Upload failed" });
        }
        setTimeout(() => setToast(null), 2500);
        setUploading(false);
      });
    } catch (e) {
      console.error("[SyncBrowserView] uploadToCloud failed:", e);
      setToast({ type: "error", message: "Upload failed" });
      setTimeout(() => setToast(null), 2500);
      setUploading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 space-y-4 relative", children: [
    toast && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `fixed right-4 top-4 z-50 rounded shadow px-4 py-2 text-sm ${toast.type === "success" ? "bg-green-600 text-white" : "bg-red-600 text-white"}`, children: toast.message }),
    uploading && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/30 backdrop-blur-sm z-40 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg shadow p-4 flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "animate-spin rounded-full h-5 w-5 border-2 border-black border-t-transparent" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-black", children: "Uploading and verifying…" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold", children: "Website list to sync with cloud browser" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "text-sm text-gray-600 hover:text-black",
          onClick: goHomeView,
          children: "Back"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end pr-1 text-xs text-gray-500 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Cookie, { className: "w-3 h-3" }),
        " Local"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Cloud, { className: "w-3 h-3" }),
        " Cloud"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: Object.keys(COOKIE_SITES).map((id) => {
      const label = SITE_ICON_LABELS[id];
      const s = statuses[id];
      const onLogin = () => {
        const url = COOKIE_SITES[id].loginUrl;
        if (url) chrome.tabs.create({ url }).catch(() => {
        });
      };
      const showLogin = (s == null ? void 0 : s.status) === "failed" || (s == null ? void 0 : s.message) && s.message.toLowerCase().includes("missing");
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full flex items-center justify-between border rounded px-3 py-2 text-left", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", children: label }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm text-gray-600 flex items-center gap-6", children: [
          showLogin ? /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onLogin, className: "underline text-black hover:text-gray-800", children: "Login" }) : null,
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Cookie, { className: "w-4 h-4 text-gray-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(StatusIcon, { status: s == null ? void 0 : s.status })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Cloud, { className: "w-4 h-4 text-gray-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(VerifyIcon, { verified: s == null ? void 0 : s.verified })
          ] }),
          (s == null ? void 0 : s.message) && s.message.toLowerCase().includes("missing") ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-orange-600", children: "Login required" }) : null,
          (s == null ? void 0 : s.message) && !s.message.toLowerCase().includes("server verified") ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-red-500", children: s.message }) : null,
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gray-400", children: formatTime(s == null ? void 0 : s.lastUpdated) })
        ] })
      ] }, id);
    }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-gray-600 mb-1", children: "Others:" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            className: "flex-1 border rounded px-3 py-2",
            placeholder: "example.com or list (comma/space separated)",
            value: othersInput,
            onChange: (e) => setOthersInput(e.target.value)
          }
        ),
        parseOthers().map((d) => {
          const key = `other:${d}`;
          const s = statuses[key];
          const onLogin = () => chrome.tabs.create({ url: `https://${d}/` }).catch(() => {
          });
          const showLogin = (s == null ? void 0 : s.status) === "failed";
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-gray-600 border rounded px-2 py-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-2", children: d }),
            showLogin ? /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onLogin, className: "underline text-black hover:text-gray-800 mr-2", children: "Login" }) : null,
            /* @__PURE__ */ jsxRuntimeExports.jsx(StatusIcon, { status: s == null ? void 0 : s.status }),
            (s == null ? void 0 : s.message) && s.message.toLowerCase().includes("missing") ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-orange-600 mr-2", children: "Login required" }) : null,
            (s == null ? void 0 : s.message) ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-red-500 mr-2", children: s.message }) : null,
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gray-400", children: formatTime(s == null ? void 0 : s.lastUpdated) })
          ] }, key);
        })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: startSync, className: "bg-black hover:bg-gray-800 text-white px-6 py-2 rounded-lg font-medium", children: "Start sync" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: uploadToCloud, className: "bg-black hover:bg-gray-800 text-white px-6 py-2 rounded-lg font-medium", children: "Upload to cloud" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Button,
        {
          onClick: () => {
            chrome.runtime.sendMessage({
              type: "DOWNLOAD_COOKIES_JSON",
              payload: { sites: selectedSites, others: parseOthers() }
            }, (resp) => {
              if (chrome.runtime.lastError) {
                console.error("[SyncBrowserView] DOWNLOAD_COOKIES_JSON failed:", chrome.runtime.lastError.message);
                return;
              }
              console.log("[SyncBrowserView] DOWNLOAD_COOKIES_JSON:", resp);
            });
          },
          className: "bg-white text-black border border-gray-300 hover:bg-gray-50 px-6 py-2 rounded-lg font-medium",
          children: "Download JSON"
        }
      )
    ] })
  ] });
};
export {
  SyncBrowserView as default
};
//# sourceMappingURL=sync-browser-view-SeAqu2JV.js.map
