var background = function() {
  "use strict";
  var _a, _b;
  function defineBackground(arg) {
    if (arg == null || typeof arg === "function") return { main: arg };
    return arg;
  }
  var EventType = /* @__PURE__ */ ((EventType2) => {
    EventType2[EventType2["DomContentLoaded"] = 0] = "DomContentLoaded";
    EventType2[EventType2["Load"] = 1] = "Load";
    EventType2[EventType2["FullSnapshot"] = 2] = "FullSnapshot";
    EventType2[EventType2["IncrementalSnapshot"] = 3] = "IncrementalSnapshot";
    EventType2[EventType2["Meta"] = 4] = "Meta";
    EventType2[EventType2["Custom"] = 5] = "Custom";
    EventType2[EventType2["Plugin"] = 6] = "Plugin";
    return EventType2;
  })(EventType || {});
  var IncrementalSource = /* @__PURE__ */ ((IncrementalSource2) => {
    IncrementalSource2[IncrementalSource2["Mutation"] = 0] = "Mutation";
    IncrementalSource2[IncrementalSource2["MouseMove"] = 1] = "MouseMove";
    IncrementalSource2[IncrementalSource2["MouseInteraction"] = 2] = "MouseInteraction";
    IncrementalSource2[IncrementalSource2["Scroll"] = 3] = "Scroll";
    IncrementalSource2[IncrementalSource2["ViewportResize"] = 4] = "ViewportResize";
    IncrementalSource2[IncrementalSource2["Input"] = 5] = "Input";
    IncrementalSource2[IncrementalSource2["TouchMove"] = 6] = "TouchMove";
    IncrementalSource2[IncrementalSource2["MediaInteraction"] = 7] = "MediaInteraction";
    IncrementalSource2[IncrementalSource2["StyleSheetRule"] = 8] = "StyleSheetRule";
    IncrementalSource2[IncrementalSource2["CanvasMutation"] = 9] = "CanvasMutation";
    IncrementalSource2[IncrementalSource2["Font"] = 10] = "Font";
    IncrementalSource2[IncrementalSource2["Log"] = 11] = "Log";
    IncrementalSource2[IncrementalSource2["Drag"] = 12] = "Drag";
    IncrementalSource2[IncrementalSource2["StyleDeclaration"] = 13] = "StyleDeclaration";
    IncrementalSource2[IncrementalSource2["Selection"] = 14] = "Selection";
    IncrementalSource2[IncrementalSource2["AdoptedStyleSheet"] = 15] = "AdoptedStyleSheet";
    IncrementalSource2[IncrementalSource2["CustomElement"] = 16] = "CustomElement";
    return IncrementalSource2;
  })(IncrementalSource || {});
  const COOKIE_SITES = {
    x: {
      id: "x",
      label: "X",
      hostPermissions: ["https://x.com/*"],
      cookieDomains: ["x.com", ".x.com"],
      enabledByDefault: true,
      requiredCookies: ["auth_token"],
      loginUrl: "https://x.com/login"
    },
    linkedin: {
      id: "linkedin",
      label: "LinkedIn",
      hostPermissions: ["https://*.linkedin.com/*"],
      cookieDomains: [
        "linkedin.com",
        ".linkedin.com",
        "www.linkedin.com",
        ".www.linkedin.com",
        "login.linkedin.com",
        ".login.linkedin.com"
      ],
      enabledByDefault: true,
      requiredCookies: ["li_at"],
      loginUrl: "https://www.linkedin.com/login"
    },
    tiktok: {
      id: "tiktok",
      label: "TikTok",
      hostPermissions: ["https://*.tiktok.com/*"],
      cookieDomains: ["tiktok.com", ".tiktok.com", "www.tiktok.com", ".www.tiktok.com"],
      enabledByDefault: true,
      loginUrl: "https://www.tiktok.com/login",
      requiredCookies: ["sessionid"]
    },
    instagram: {
      id: "instagram",
      label: "Instagram",
      hostPermissions: ["https://*.instagram.com/*"],
      cookieDomains: [
        "instagram.com",
        ".instagram.com",
        "www.instagram.com",
        ".www.instagram.com",
        "m.instagram.com",
        ".m.instagram.com"
      ],
      enabledByDefault: true,
      requiredCookies: ["sessionid"],
      loginUrl: "https://www.instagram.com/accounts/login"
    },
    facebook: {
      id: "facebook",
      label: "Facebook",
      hostPermissions: ["https://*.facebook.com/*"],
      cookieDomains: ["facebook.com", ".facebook.com", "www.facebook.com", ".www.facebook.com"],
      enabledByDefault: true,
      requiredCookies: ["c_user", "xs"],
      loginUrl: "https://www.facebook.com/login"
    }
  };
  background;
  const toUniqueSorted = (arr) => Array.from(new Set(arr)).sort();
  const getAllGrantedOrigins = async () => {
    const all = await chrome.permissions.getAll();
    return toUniqueSorted(all.origins ?? []);
  };
  const checkOrigins = async (origins) => {
    const required = toUniqueSorted(origins);
    const grantedOrigins = await getAllGrantedOrigins();
    const grantedSet = new Set(grantedOrigins);
    const hasAllUrls = grantedSet.has("<all_urls>") || grantedSet.has("https://*/*") && grantedSet.has("http://*/*");
    const isGranted = (origin) => hasAllUrls || grantedSet.has(origin);
    const granted = required.filter((o) => isGranted(o));
    const missing = required.filter((o) => !isGranted(o));
    return { required, granted, missing };
  };
  const getSiteHostPermissions = (siteId) => {
    const site = COOKIE_SITES[siteId];
    return toUniqueSorted(site.hostPermissions);
  };
  const buildHostPermissionPatternsForDomain = (domain) => {
    const normalized = domain.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/$/, "");
    if (!normalized) return [];
    return [`https://${normalized}/*`, `https://*.${normalized}/*`];
  };
  background;
  const toAscii = (h) => {
    try {
      const u = new URL(`http://${h}`);
      return u.hostname;
    } catch {
      return h;
    }
  };
  const strip = (s) => s.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*/, "").replace(/:\d+$/, "");
  const heuristicApex = (host) => {
    const parts = host.split(".").filter(Boolean);
    if (parts.length <= 2) return host;
    const twoPartTlds = /* @__PURE__ */ new Set(["co.uk", "com.au", "co.jp"]);
    const last2 = parts.slice(-2).join(".");
    parts.slice(-3).join(".");
    if (twoPartTlds.has(last2)) return parts.slice(-3).join(".");
    return last2;
  };
  function normalizeDomain(input) {
    const stripped = strip(input);
    const hostname = toAscii(stripped);
    if (!hostname || hostname.includes("*") || !hostname.includes(".")) {
      throw new Error("Invalid domain");
    }
    const apex = heuristicApex(hostname);
    return {
      input,
      hostname,
      apex,
      permissionPatterns: [`https://${apex}/*`, `https://*.${apex}/*`],
      cookieDomains: [apex, `.${apex}`]
    };
  }
  background;
  const sameSiteMap = {
    no_restriction: "None",
    lax: "Lax",
    strict: "Strict"
  };
  const keyOf = (c) => `${c.domain}|${c.path}|${c.name}`;
  function mapChromeCookiesToPlaywright(cookies) {
    const dedup = /* @__PURE__ */ new Map();
    for (const c of cookies) {
      if (!c.name || c.value === void 0 || c.value === null) continue;
      const k = keyOf(c);
      const prev = dedup.get(k);
      if (!prev || (c.expirationDate ?? 0) > (prev.expirationDate ?? 0)) dedup.set(k, c);
    }
    const out = Array.from(dedup.values()).map((c) => ({
      name: c.name,
      value: c.value,
      domain: c.domain,
      path: c.path,
      expires: Math.trunc(c.expirationDate ?? 0),
      httpOnly: !!c.httpOnly,
      secure: !!c.secure,
      sameSite: sameSiteMap[String(c.sameSite)] ?? "Lax"
    }));
    return { cookies: out, origins: [] };
  }
  function validateRequiredCookies(siteId, cookies) {
    var _a2, _b2;
    const req = ((_a2 = COOKIE_SITES[siteId]) == null ? void 0 : _a2.requiredCookies) || [];
    const byName = cookies.reduce((acc, c) => {
      var _a3;
      (acc[_a3 = c.name] || (acc[_a3] = [])).push(c);
      return acc;
    }, {});
    const missing = [];
    for (const r of req) if (!((_b2 = byName[r]) == null ? void 0 : _b2.length)) missing.push(r);
    let ok = missing.length === 0;
    let reason;
    if (ok) {
      if (siteId === "facebook") {
        const xsGood = (byName["xs"] || []).some((c) => c.httpOnly === true && c.secure === true);
        const cUserGood = (byName["c_user"] || []).some((c) => (c.value ?? "").length > 0);
        if (!xsGood) {
          ok = false;
          reason = "xs must be httpOnly & secure";
        }
        if (!cUserGood) {
          ok = false;
          reason = reason ?? "c_user missing or empty";
        }
      } else if (siteId === "linkedin") {
        const liAtGood = (byName["li_at"] || []).some((c) => c.httpOnly === true);
        (byName["JSESSIONID"] || []).length > 0 ? true : true;
        if (!liAtGood) {
          ok = false;
          reason = "li_at must be httpOnly";
        }
      } else if (siteId === "instagram") {
        const sidGood = (byName["sessionid"] || []).some((c) => c.httpOnly === true);
        if (!sidGood) {
          ok = false;
          reason = "sessionid must be httpOnly";
        }
      } else if (siteId === "x") {
        const atGood = (byName["auth_token"] || []).some((c) => c.httpOnly === true);
        if (!atGood) {
          ok = false;
          reason = "auth_token must be httpOnly";
        }
      } else if (siteId === "tiktok") {
        const sessGood = (byName["sessionid"] || []).length > 0;
        if (!sessGood) {
          ok = false;
          reason = "sessionid missing";
        }
      }
    }
    return { ok, missing, message: ok ? void 0 : missing.length ? `Missing: ${missing.join(", ")}` : reason };
  }
  background;
  const b64encode = (buf) => {
    const bytes = new Uint8Array(buf);
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };
  const utf8encode = (s) => new TextEncoder().encode(s);
  async function fetchPublicKey() {
    const url = `${"https://wf-be.up.railway.app"}/crypto/public-key`;
    const res = await fetch(url, { method: "GET" });
    if (!res.ok) throw new Error(`Failed to fetch public key: ${res.status}`);
    const data = await res.json();
    const pem = data.pem.replace(/-----BEGIN PUBLIC KEY-----|-----END PUBLIC KEY-----|\s+/g, "");
    const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
    const key = await crypto.subtle.importKey(
      "spki",
      der,
      { name: "RSA-OAEP", hash: "SHA-256" },
      false,
      ["wrapKey"]
    );
    return { kid: data.kid, key };
  }
  async function encryptEnvelope(plaintextJson, rsaPublicKey) {
    const dataKeyRaw = crypto.getRandomValues(new Uint8Array(32));
    const aesKey = await crypto.subtle.importKey("raw", dataKeyRaw, { name: "AES-GCM" }, true, ["encrypt", "decrypt"]);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, aesKey, utf8encode(plaintextJson));
    const wrapped = await crypto.subtle.wrapKey("raw", aesKey, rsaPublicKey, { name: "RSA-OAEP" });
    return {
      nonceB64: b64encode(iv.buffer),
      ciphertextB64: b64encode(ciphertext),
      wrappedKeyB64: b64encode(wrapped)
    };
  }
  background;
  const definition = defineBackground(() => {
    const sessionLogs = {};
    const tabInfo = {};
    let isRecordingEnabled = false;
    let lastWorkflowHash = null;
    let cookieStatusMap = {};
    const PYTHON_SERVER_ENDPOINT = `${"https://wf-be.up.railway.app"}/event`;
    async function calculateSHA256(str) {
      const encoder = new TextEncoder();
      const data = encoder.encode(str);
      const hashBuffer = await crypto.subtle.digest("SHA-256", data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
      return hashHex;
    }
    async function sendEventToServer(eventData) {
      try {
        await fetch(PYTHON_SERVER_ENDPOINT, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(eventData)
        });
      } catch (error) {
        console.warn(
          `Failed to send event to Python server at ${PYTHON_SERVER_ENDPOINT}:`,
          error
        );
      }
    }
    async function broadcastWorkflowDataUpdate() {
      const allSteps = Object.keys(sessionLogs).flatMap((tabIdStr) => {
        const tabId = parseInt(tabIdStr, 10);
        return convertStoredEventsToSteps(sessionLogs[tabId] || []);
      }).sort((a, b) => a.timestamp - b.timestamp);
      const workflowData = {
        name: "Recorded Workflow",
        description: `Recorded on ${(/* @__PURE__ */ new Date()).toLocaleString()}`,
        version: "1.0.0",
        input_schema: [],
        steps: allSteps
        // allSteps is used here
      };
      const allStepsString = JSON.stringify(allSteps);
      const currentWorkflowHash = await calculateSHA256(allStepsString);
      if (lastWorkflowHash !== null && currentWorkflowHash === lastWorkflowHash) {
        return workflowData;
      }
      lastWorkflowHash = currentWorkflowHash;
      const eventToSend = {
        type: "WORKFLOW_UPDATE",
        timestamp: Date.now(),
        payload: workflowData
      };
      sendEventToServer(eventToSend);
      return workflowData;
    }
    function broadcastRecordingStatus() {
      const statusString = isRecordingEnabled ? "recording" : "stopped";
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
          if (tab.id) {
            chrome.tabs.sendMessage(tab.id, {
              type: "SET_RECORDING_STATUS",
              payload: isRecordingEnabled
            }).catch((err) => {
            });
          }
        });
      });
      chrome.runtime.sendMessage({
        type: "recording_status_updated",
        payload: { status: statusString }
        // Send string status
      }).catch((err) => {
      });
    }
    function sendTabEvent(type, payload) {
      if (!isRecordingEnabled) return;
      console.log(`Sending ${type}:`, payload);
      const tabId = payload.tabId;
      if (tabId) {
        if (!sessionLogs[tabId]) {
          sessionLogs[tabId] = [];
        }
        sessionLogs[tabId].push({
          messageType: type,
          timestamp: Date.now(),
          tabId,
          ...payload
        });
        broadcastWorkflowDataUpdate();
      } else {
        console.warn(
          "Tab event received without tabId in payload:",
          type,
          payload
        );
      }
    }
    chrome.tabs.onCreated.addListener((tab) => {
      sendTabEvent("CUSTOM_TAB_CREATED", {
        tabId: tab.id,
        openerTabId: tab.openerTabId,
        url: tab.pendingUrl || tab.url,
        windowId: tab.windowId,
        index: tab.index
      });
    });
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      if (changeInfo.url || changeInfo.status === "complete") {
        sendTabEvent("CUSTOM_TAB_UPDATED", {
          tabId,
          changeInfo,
          // includes URL, status, title etc.
          windowId: tab.windowId,
          url: tab.url,
          title: tab.title
        });
      }
    });
    chrome.tabs.onActivated.addListener((activeInfo) => {
      sendTabEvent("CUSTOM_TAB_ACTIVATED", {
        tabId: activeInfo.tabId,
        windowId: activeInfo.windowId
      });
    });
    chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
      sendTabEvent("CUSTOM_TAB_REMOVED", {
        tabId,
        windowId: removeInfo.windowId,
        isWindowClosing: removeInfo.isWindowClosing
      });
    });
    function convertStoredEventsToSteps(events) {
      var _a2, _b2;
      const steps = [];
      for (const event of events) {
        switch (event.messageType) {
          case "CUSTOM_CLICK_EVENT": {
            const clickEvent = event;
            if (clickEvent.url && clickEvent.frameUrl && clickEvent.xpath && clickEvent.elementTag) {
              const step = {
                type: "click",
                timestamp: clickEvent.timestamp,
                tabId: clickEvent.tabId,
                url: clickEvent.url,
                frameUrl: clickEvent.frameUrl,
                xpath: clickEvent.xpath,
                cssSelector: clickEvent.cssSelector,
                elementTag: clickEvent.elementTag,
                elementText: clickEvent.elementText,
                screenshot: clickEvent.screenshot
              };
              steps.push(step);
            } else {
              console.warn("Skipping incomplete CUSTOM_CLICK_EVENT:", clickEvent);
            }
            break;
          }
          case "CUSTOM_INPUT_EVENT": {
            const inputEvent = event;
            if (inputEvent.url && // inputEvent.frameUrl && // frameUrl might be null/undefined in some cases, let's allow merging if only one is present or both match
            inputEvent.xpath && inputEvent.elementTag) {
              const lastStep = steps.length > 0 ? steps[steps.length - 1] : null;
              if (lastStep && lastStep.type === "input" && lastStep.tabId === inputEvent.tabId && lastStep.url === inputEvent.url && lastStep.frameUrl === inputEvent.frameUrl && // Ensure frameUrls match if both exist
              lastStep.xpath === inputEvent.xpath && lastStep.cssSelector === inputEvent.cssSelector && lastStep.elementTag === inputEvent.elementTag) {
                lastStep.value = inputEvent.value;
                lastStep.timestamp = inputEvent.timestamp;
                lastStep.screenshot = inputEvent.screenshot;
              } else {
                const newStep = {
                  type: "input",
                  timestamp: inputEvent.timestamp,
                  tabId: inputEvent.tabId,
                  url: inputEvent.url,
                  frameUrl: inputEvent.frameUrl,
                  xpath: inputEvent.xpath,
                  cssSelector: inputEvent.cssSelector,
                  elementTag: inputEvent.elementTag,
                  value: inputEvent.value,
                  screenshot: inputEvent.screenshot
                };
                steps.push(newStep);
              }
            } else {
              console.warn("Skipping incomplete CUSTOM_INPUT_EVENT:", inputEvent);
            }
            break;
          }
          case "CUSTOM_KEY_EVENT": {
            const keyEvent = event;
            if (keyEvent.url && keyEvent.key) {
              const step = {
                type: "key_press",
                timestamp: keyEvent.timestamp,
                tabId: keyEvent.tabId,
                url: keyEvent.url,
                frameUrl: keyEvent.frameUrl,
                // Can be missing
                key: keyEvent.key,
                xpath: keyEvent.xpath,
                cssSelector: keyEvent.cssSelector,
                elementTag: keyEvent.elementTag,
                screenshot: keyEvent.screenshot
              };
              steps.push(step);
            } else {
              console.warn("Skipping incomplete CUSTOM_KEY_EVENT:", keyEvent);
            }
            break;
          }
          case "RRWEB_EVENT": {
            const rrEvent = event;
            if (rrEvent.type === 5 && ((_a2 = rrEvent.data) == null ? void 0 : _a2.tag) === "clipboard") {
              const clipboardData = rrEvent.data.payload;
              if (clipboardData.clipboardType === "copy") {
                const step = {
                  type: "clipboard_copy",
                  timestamp: rrEvent.timestamp,
                  tabId: rrEvent.tabId,
                  url: clipboardData.url || "",
                  frameUrl: clipboardData.frameUrl,
                  xpath: clipboardData.xpath,
                  cssSelector: clipboardData.cssSelector,
                  elementTag: clipboardData.elementTag,
                  elementText: clipboardData.elementText,
                  content: clipboardData.content || "",
                  screenshot: void 0
                  // TODO: Add screenshot capture for clipboard events
                };
                steps.push(step);
                console.log("📋 Added clipboard copy step:", step);
              } else if (clipboardData.clipboardType === "paste") {
                const step = {
                  type: "clipboard_paste",
                  timestamp: rrEvent.timestamp,
                  tabId: rrEvent.tabId,
                  url: clipboardData.url || "",
                  frameUrl: clipboardData.frameUrl,
                  xpath: clipboardData.xpath,
                  cssSelector: clipboardData.cssSelector,
                  elementTag: clipboardData.elementTag,
                  elementText: clipboardData.elementText,
                  content: clipboardData.content,
                  screenshot: void 0
                  // TODO: Add screenshot capture for clipboard events
                };
                steps.push(step);
                console.log("📋 Added clipboard paste step:", step);
              }
            } else if (rrEvent.type === EventType.IncrementalSnapshot && rrEvent.data.source === IncrementalSource.Scroll) {
              const scrollData = rrEvent.data;
              const currentTabInfo = tabInfo[rrEvent.tabId];
              const lastStep = steps.length > 0 ? steps[steps.length - 1] : null;
              if (lastStep && lastStep.type === "scroll" && lastStep.tabId === rrEvent.tabId && lastStep.targetId === scrollData.id) {
                lastStep.scrollX = scrollData.x;
                lastStep.scrollY = scrollData.y;
                lastStep.timestamp = rrEvent.timestamp;
              } else {
                const newStep = {
                  type: "scroll",
                  timestamp: rrEvent.timestamp,
                  tabId: rrEvent.tabId,
                  targetId: scrollData.id,
                  scrollX: scrollData.x,
                  scrollY: scrollData.y,
                  url: currentTabInfo == null ? void 0 : currentTabInfo.url
                  // Add URL if available
                };
                steps.push(newStep);
              }
            } else if (rrEvent.type === EventType.Meta && ((_b2 = rrEvent.data) == null ? void 0 : _b2.href)) {
              const metaData = rrEvent.data;
              const step = {
                type: "navigation",
                timestamp: rrEvent.timestamp,
                tabId: rrEvent.tabId,
                url: metaData.href
              };
              steps.push(step);
            }
            break;
          }
        }
      }
      return steps;
    }
    const customEventTypes = [
      "CUSTOM_CLICK_EVENT",
      "CUSTOM_INPUT_EVENT",
      "CUSTOM_SELECT_EVENT",
      "CUSTOM_KEY_EVENT"
    ];
    const handleContentEvent = (type, message, sender) => {
      var _a2, _b2;
      if (!isRecordingEnabled) return false;
      if (!((_a2 = sender.tab) == null ? void 0 : _a2.id)) {
        console.warn("Received event without tab ID:", message);
        return false;
      }
      const tabId = sender.tab.id;
      const storeEvent = (eventPayload, screenshotDataUrl) => {
        var _a3, _b3;
        if (!sessionLogs[tabId]) sessionLogs[tabId] = [];
        if (!tabInfo[tabId]) tabInfo[tabId] = {};
        if (((_a3 = sender.tab) == null ? void 0 : _a3.url) && !tabInfo[tabId].url) tabInfo[tabId].url = sender.tab.url;
        if (((_b3 = sender.tab) == null ? void 0 : _b3.title) && !tabInfo[tabId].title) tabInfo[tabId].title = sender.tab.title;
        const eventWithMeta = { ...eventPayload, tabId, messageType: type, screenshot: screenshotDataUrl };
        sessionLogs[tabId].push(eventWithMeta);
        broadcastWorkflowDataUpdate();
      };
      const isCustom = customEventTypes.includes(type);
      if (isCustom && ((_b2 = sender.tab) == null ? void 0 : _b2.windowId)) {
        chrome.tabs.captureVisibleTab(
          sender.tab.windowId,
          { format: "jpeg", quality: 75 },
          (dataUrl) => {
            if (chrome.runtime.lastError) {
              console.error("Screenshot failed:", chrome.runtime.lastError.message);
              storeEvent(message.payload);
            } else {
              storeEvent(message.payload, dataUrl);
            }
          }
        );
        return false;
      }
      if (type === "RRWEB_EVENT") {
        storeEvent(message.payload);
        return false;
      }
      if (isCustom) {
        console.warn("Storing custom event without screenshot due to missing windowId or other issue.");
        storeEvent(message.payload);
        return false;
      }
      return false;
    };
    const handleGetRecordingData = async (_message, _sender, sendResponse) => {
      const workflowData = await broadcastWorkflowDataUpdate();
      const statusString = isRecordingEnabled ? "recording" : workflowData.steps.length > 0 ? "stopped" : "idle";
      sendResponse({ workflow: workflowData, recordingStatus: statusString });
    };
    const handleStartRecording = (_message, _sender, sendResponse) => {
      console.log("Received START_RECORDING request.");
      Object.keys(sessionLogs).forEach((key) => delete sessionLogs[parseInt(key)]);
      Object.keys(tabInfo).forEach((key) => delete tabInfo[parseInt(key)]);
      console.log("Cleared previous recording data.");
      if (!isRecordingEnabled) {
        isRecordingEnabled = true;
        console.log("Recording status set to: true");
        broadcastRecordingStatus();
        const eventToSend = { type: "RECORDING_STARTED", timestamp: Date.now(), payload: { message: "Recording has started" } };
        sendEventToServer(eventToSend);
      }
      sendResponse({ status: "started" });
    };
    const handleStopRecording = (_message, _sender, sendResponse) => {
      console.log("Received STOP_RECORDING request.");
      if (isRecordingEnabled) {
        isRecordingEnabled = false;
        console.log("Recording status set to: false");
        broadcastRecordingStatus();
        const eventToSend = { type: "RECORDING_STOPPED", timestamp: Date.now(), payload: { message: "Recording has stopped" } };
        sendEventToServer(eventToSend);
      }
      sendResponse({ status: "stopped" });
    };
    const handleStartCookieSync = async (message, _sender, sendResponse) => {
      var _a2;
      try {
        const { requestId, sites = [], others = [] } = message.payload || {};
        console.log("[CookieSync] START received:", { requestId, sites, others });
        sendResponse({ ok: true });
        const allTargets = [...sites, ...others.map((d) => `other:${d}`)];
        const persistStatus = async (siteId, status, message2) => {
          const key = "cookieSyncStatusMap";
          cookieStatusMap[siteId] = { status, lastUpdated: Date.now(), message: message2 };
          await chrome.storage.local.set({ [key]: cookieStatusMap });
        };
        const runForTarget = async (siteId) => {
          var _a3, _b2;
          const progressStart = { type: "COOKIE_SYNC_PROGRESS", payload: { requestId, site: { siteId, status: "processing", lastUpdated: Date.now() } } };
          chrome.runtime.sendMessage(progressStart).catch(() => {
          });
          await persistStatus(siteId, "processing");
          try {
            if (siteId.startsWith("other:")) {
              const domain = siteId.split(":", 2)[1];
              const origins = buildHostPermissionPatternsForDomain(domain);
              const perm = await checkOrigins(origins);
              if ((_a3 = perm.missing) == null ? void 0 : _a3.length) {
                const msg = "Permission not granted";
                const deniedMsg = { type: "COOKIE_SYNC_PROGRESS", payload: { requestId, site: { siteId, status: "failed", lastUpdated: Date.now(), message: msg } } };
                chrome.runtime.sendMessage(deniedMsg).catch(() => {
                });
                await persistStatus(siteId, "failed", msg);
                return { siteId, ok: false };
              }
            } else {
              const isCookieSiteId2 = (v) => Object.keys(COOKIE_SITES).includes(String(v));
              if (isCookieSiteId2(siteId)) {
                const origins = getSiteHostPermissions(siteId);
                const perm = await checkOrigins(origins);
                if ((_b2 = perm.missing) == null ? void 0 : _b2.length) {
                  const msg = "Permission not granted";
                  const deniedMsg = { type: "COOKIE_SYNC_PROGRESS", payload: { requestId, site: { siteId, status: "failed", lastUpdated: Date.now(), message: msg } } };
                  chrome.runtime.sendMessage(deniedMsg).catch(() => {
                  });
                  await persistStatus(siteId, "failed", msg);
                  return { siteId, ok: false };
                }
              }
            }
          } catch {
          }
          let cookies = [];
          try {
            if (siteId.startsWith("other:")) {
              const domain = siteId.split(":", 2)[1];
              const list1 = await chrome.cookies.getAll({ domain });
              const list2 = await chrome.cookies.getAll({ domain: `.${domain}` });
              cookies = [...list1 || [], ...list2 || []];
            } else {
              const isCookieSiteId2 = (v) => Object.keys(COOKIE_SITES).includes(String(v));
              if (isCookieSiteId2(siteId)) {
                const domains = COOKIE_SITES[siteId].cookieDomains;
                for (const d of domains) {
                  const list = await chrome.cookies.getAll({ domain: d });
                  if (list == null ? void 0 : list.length) cookies.push(...list);
                }
              }
            }
          } catch (e) {
            console.warn("[CookieSync] collection failed for", siteId, e);
          }
          let ok = true;
          let msgText;
          const isCookieSiteId = (v) => Object.keys(COOKIE_SITES).includes(String(v));
          if (isCookieSiteId(siteId)) {
            const res = validateRequiredCookies(siteId, cookies);
            ok = res.ok;
            msgText = res.message;
          }
          const progressEnd = { type: "COOKIE_SYNC_PROGRESS", payload: { requestId, site: { siteId, status: ok ? "success" : "failed", lastUpdated: Date.now(), message: msgText } } };
          chrome.runtime.sendMessage(progressEnd).catch(() => {
          });
          await persistStatus(siteId, ok ? "success" : "failed", msgText);
          return { siteId, ok };
        };
        const results = await Promise.all(allTargets.map(runForTarget));
        const done = { type: "COOKIE_SYNC_DONE", payload: { requestId, results: results.map((r) => ({ siteId: r.siteId, status: r.ok ? "success" : "failed", lastUpdated: Date.now() })) } };
        chrome.runtime.sendMessage(done).catch(() => {
        });
      } catch (err) {
        console.error("[CookieSync] START handler failed:", err);
        try {
          chrome.runtime.sendMessage({ type: "COOKIE_SYNC_ERROR", payload: { requestId: (_a2 = message == null ? void 0 : message.payload) == null ? void 0 : _a2.requestId, error: String(err) } }).catch(() => {
          });
        } catch {
        }
      }
    };
    const handleGetSiteCookies = (message, _sender, sendResponse) => {
      (async () => {
        var _a2, _b2;
        try {
          const { siteId, domain, storeId } = message.payload || {};
          const siteKey = siteId ?? (domain ? `other:${domain}` : "unknown");
          let queryDomains = [];
          const isCookieSiteId = (v) => Object.keys(COOKIE_SITES).includes(String(v));
          if (isCookieSiteId(siteId)) queryDomains = COOKIE_SITES[siteId].cookieDomains;
          else if (domain) {
            const d = domain.trim().toLowerCase();
            queryDomains = [d, `.${d}`];
          }
          const allCookies = [];
          for (const d of queryDomains) {
            const list = await chrome.cookies.getAll({ domain: d, storeId });
            if (list && list.length) allCookies.push(...list);
          }
          console.log(`[CookieFetch] ${siteKey} -> ${allCookies.length} cookies`, allCookies);
          sendResponse({ ok: true, siteKey, cookies: allCookies });
        } catch (e) {
          console.error("[CookieFetch] failed:", e);
          sendResponse({ ok: false, siteKey: ((_a2 = message.payload) == null ? void 0 : _a2.siteId) ?? ((_b2 = message.payload) == null ? void 0 : _b2.domain), error: String(e) });
        }
      })();
      return true;
    };
    const handleDownloadCookiesJson = (message, _sender, sendResponse) => {
      (async () => {
        try {
          const { sites = [], others = [], storeId } = message.payload || {};
          const targets = [];
          const isCookieSiteId = (v) => Object.keys(COOKIE_SITES).includes(String(v));
          for (const s of sites) {
            if (isCookieSiteId(s)) targets.push({ key: s, domains: COOKIE_SITES[s].cookieDomains });
          }
          for (const dRaw of others) {
            const d = String(dRaw).trim().toLowerCase();
            if (!d) continue;
            targets.push({ key: `other:${d}`, domains: [d, `.${d}`] });
          }
          const collected = [];
          for (const t of targets) {
            for (const dom of t.domains) {
              const list = await chrome.cookies.getAll({ domain: dom, storeId });
              if (list == null ? void 0 : list.length) collected.push(...list);
            }
          }
          const { cookies: cookiesOut } = mapChromeCookiesToPlaywright(collected);
          try {
            const siteReqs = {
              x: ["auth_token"],
              linkedin: ["li_at"],
              instagram: ["sessionid"],
              facebook: ["c_user", "xs"]
            };
            const namesSet = new Set(cookiesOut.map((c) => c.name));
            const missingPerSite = [];
            for (const [site, reqs] of Object.entries(siteReqs)) {
              const miss = reqs.filter((r) => !namesSet.has(r));
              if (miss.length) missingPerSite.push(`${site}:${miss.join("+")}`);
            }
            if (missingPerSite.length) {
              console.warn("[DownloadCookies] Missing required before download:", missingPerSite.join(", "));
            }
          } catch {
          }
          const payload = { cookies: cookiesOut, origins: [] };
          const json = JSON.stringify(payload, null, 2);
          const url = "data:application/json;charset=utf-8," + encodeURIComponent(json);
          const filename = `storage_state_${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.json`;
          await chrome.downloads.download({ url, filename, saveAs: true });
          sendResponse({ ok: true, count: cookiesOut.length });
        } catch (e) {
          console.error("[DownloadCookies] failed:", e);
          sendResponse({ ok: false, error: String(e) });
        }
      })();
      return true;
    };
    const handleBuildCookiesJson = (message, _sender, sendResponse) => {
      (async () => {
        try {
          const { sites = [], others = [], storeId } = message.payload || {};
          const targets = [];
          const isCookieSiteId = (v) => Object.keys(COOKIE_SITES).includes(String(v));
          for (const s of sites) {
            if (isCookieSiteId(s)) targets.push({ key: s, domains: COOKIE_SITES[s].cookieDomains });
          }
          for (const dRaw of others) {
            const norm = normalizeDomain(String(dRaw));
            targets.push({ key: `other:${norm.apex}`, domains: norm.cookieDomains });
          }
          const collected = [];
          for (const t of targets) {
            for (const dom of t.domains) {
              const list = await chrome.cookies.getAll({ domain: dom, storeId });
              if (list == null ? void 0 : list.length) collected.push(...list);
            }
          }
          const payload = mapChromeCookiesToPlaywright(collected);
          sendResponse({ ok: true, json: JSON.stringify(payload), count: payload.cookies.length });
        } catch (e) {
          console.error("[BuildCookiesJson] failed:", e);
          sendResponse({ ok: false, error: String(e) });
        }
      })();
      return true;
    };
    const handleUploadCookiesEncrypted = (message, _sender, sendResponse) => {
      (async () => {
        try {
          const { payloadJson, ott, sites } = message.payload || {};
          if (!payloadJson || !ott) throw new Error("missing payloadJson or ott");
          const { kid, key } = await fetchPublicKey();
          const { nonceB64, ciphertextB64, wrappedKeyB64 } = await encryptEnvelope(payloadJson, key);
          const res = await fetch(`${"https://wf-be.up.railway.app"}/auth/storage-state`, {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": `Bearer ${ott}` },
            body: JSON.stringify({
              ciphertext: ciphertextB64,
              nonce: nonceB64,
              wrappedKey: wrappedKeyB64,
              kid,
              metadata: { sites, createdAt: (/* @__PURE__ */ new Date()).toISOString(), version: "cookies-v1" }
            })
          });
          if (!res.ok) throw new Error(`upload failed: ${res.status}`);
          const json = await res.json();
          sendResponse({ ok: true, result: json });
        } catch (e) {
          console.error("[UploadCookiesEncrypted] failed:", e);
          sendResponse({ ok: false, error: String(e) });
        }
      })();
      return true;
    };
    const handleRequestRecordingStatus = (_message, sender, sendResponse) => {
      var _a2;
      if (!((_a2 = sender.tab) == null ? void 0 : _a2.id)) return false;
      console.log(`Sending initial status (${isRecordingEnabled}) to tab ${sender.tab.id}`);
      setTimeout(() => {
        sendResponse({ isRecordingEnabled });
      }, 50);
      return true;
    };
    const messageHandlers = {
      // Content events
      RRWEB_EVENT: (m, s) => handleContentEvent("RRWEB_EVENT", m, s),
      CUSTOM_CLICK_EVENT: (m, s) => handleContentEvent("CUSTOM_CLICK_EVENT", m, s),
      CUSTOM_INPUT_EVENT: (m, s) => handleContentEvent("CUSTOM_INPUT_EVENT", m, s),
      CUSTOM_SELECT_EVENT: (m, s) => handleContentEvent("CUSTOM_SELECT_EVENT", m, s),
      CUSTOM_KEY_EVENT: (m, s) => handleContentEvent("CUSTOM_KEY_EVENT", m, s),
      // Control
      GET_RECORDING_DATA: handleGetRecordingData,
      START_RECORDING: handleStartRecording,
      STOP_RECORDING: handleStopRecording,
      // Cookie sync & cookies
      START_COOKIE_SYNC: handleStartCookieSync,
      GET_SITE_COOKIES: handleGetSiteCookies,
      DOWNLOAD_COOKIES_JSON: handleDownloadCookiesJson,
      BUILD_COOKIES_JSON: handleBuildCookiesJson,
      UPLOAD_COOKIES_ENCRYPTED: handleUploadCookiesEncrypted,
      // Status
      REQUEST_RECORDING_STATUS: handleRequestRecordingStatus
    };
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      const handler = messageHandlers[message == null ? void 0 : message.type];
      if (!handler) return false;
      try {
        const result2 = handler(message, sender, sendResponse);
        if (result2 === true) return true;
        if (result2 && typeof result2.then === "function") {
          result2.catch((e) => console.error("Async handler failed:", e));
          return true;
        }
        return false;
      } catch (e) {
        console.error("Handler threw:", e);
        return false;
      }
    });
    (async () => {
      try {
        const key = "cookieSyncStatusMap";
        const res = await chrome.storage.local.get([key]);
        cookieStatusMap = (res == null ? void 0 : res[key]) ?? {};
      } catch {
      }
    })();
    console.log(
      "Background script loaded. Initial recording status:",
      isRecordingEnabled,
      "(EventType:",
      EventType,
      ", IncrementalSource:",
      IncrementalSource,
      ")"
      // Log imported constants
    );
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => console.error("Failed to set panel behavior:", error));
    chrome.runtime.onMessage.addListener(async (msg) => {
      if (msg.type !== "STOP_RECORDING") return;
      try {
        const workflow = await broadcastWorkflowDataUpdate();
        console.log("🔄 [Background] Automatic upload disabled - user should use sidepanel upload");
      } catch (err) {
        console.error("[workflow-use] background process failed:", err);
        chrome.notifications.create({
          type: "basic",
          iconUrl: chrome.runtime.getURL("icon/48.png"),
          title: "Background process failed",
          message: String(err)
        });
      }
    });
  });
  background;
  function initPlugins() {
  }
  ((_b = (_a = globalThis.browser) == null ? void 0 : _a.runtime) == null ? void 0 : _b.id) ? globalThis.browser : globalThis.chrome;
  function print(method, ...args) {
    return;
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  let result;
  try {
    initPlugins();
    result = definition.main();
    if (result instanceof Promise) {
      console.warn(
        "The background's main() function return a promise, but it must be synchronous"
      );
    }
  } catch (err) {
    logger.error("The background crashed on startup!");
    throw err;
  }
  const result$1 = result;
  return result$1;
}();
background;
//# sourceMappingURL=background.js.map
